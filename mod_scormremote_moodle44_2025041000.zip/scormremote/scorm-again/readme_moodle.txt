Description of import into mod_scormremote:

    1. Clone the scorm-again repository somewhere
```
git clone git@github.com:jcputney/scorm-again.git
```

    2. Copy the dist/scorm12.* files into the scorm-again folder
```
cp ~/scorm-again/dist/scorm12.* ~/mod/scormremote/scorm-again/
```
